import os
import librosa
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from keras import layers, models

# Yeni kaydedilecek model dosyasının isminini döndürür
def get_new_model_version():
    latest_version = 0
    for folder in os.listdir('models'):
        if folder.startswith('model_v'):
            version_str = folder.split('_v')[1]
            version = int(version_str)
            latest_version = max(latest_version, version)

    # Yeni model için klasör oluştur
    os.mkdir('models/model_v{}'.format(latest_version + 1))
    return "model_v{}".format(latest_version + 1)


# Öznitelik çıkarım fonksiyonu
def extract_features(file):
    # Librosa kütüphanesi kullanarak audio dosyasından öznitelikler çıkarılır
    y, sr = librosa.load(file, mono=True)
    chroma = np.mean(librosa.feature.chroma_stft(y=y, sr=sr), axis=1)
    mfcc = np.mean(librosa.feature.mfcc(y=y, sr=sr), axis=1)
    spectral_contrast = np.mean(librosa.feature.spectral_contrast(y=y, sr=sr), axis=1)
    tonnetz = np.mean(librosa.feature.tonnetz(y=y, sr=sr), axis=1)
    return chroma, mfcc, spectral_contrast, tonnetz

# Ayrıştırma fonksiyonu
def parse_audio_files(path):
    print("Ayrıştırma işlemi başladı")
    print("Dosya yolu: " + path)
    features, labels = [], []
    file_count = 0
    for subdir, dirs, files in os.walk('dataset/' + path):
        print("Alt dizin: " + subdir)
        for file in files:
            if file.endswith('.mp3'):
                try:
                    file_id = int(file[:-4])
                    genre = tracks.loc[file_id, ('track', 'genre_top')]
                    chroma, mfcc, spectral_contrast, tonnetz = extract_features(os.path.join(subdir, file))
                    features.append(np.hstack([chroma, mfcc, spectral_contrast, tonnetz]))
                    labels.append(genre)
                    file_count += 1
                    print(f"{file_count}. dosya işlendi: {file}")
                except Exception as e:
                    print(f"Dosya işlenirken hata oluştu: {file}, hata: {e}")

    # Label encoder ile türlerin sayısal değerlere dönüştürülmesi
    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(labels)

    # Label encoder'ı uygulamada kullanabilmek için kaydetme
    np.save(f'models/{model_version}/label_encoder.npy', label_encoder)

    return np.array(features), y


if __name__ == '__main__':
    # FindGenre Model Eğitimi
    print("FindGenre Model Eğitimi")

    # Veri seti yükleme
    print("Veri seti yükleniyor")
    tracks = pd.read_csv('dataset/fma_metadata/tracks.csv', index_col=0, header=[0, 1])
    tracks = tracks.loc[tracks[('set', 'subset')] == 'small', :]
    tracks = tracks.dropna(subset=[('track', 'genre_top')])

    model_version = get_new_model_version()

    # Ses dosyalarının işlenmesi
    print("Ses dosyaları işleniyor")
    features, y = parse_audio_files('fma_small')

    # Özelliklerin standartlaştırılması
    print("Özellikler standartlaştırılıyor")
    X = StandardScaler().fit_transform(features)

    # Eğitim ve test setlerinin oluşturulması
    print("Eğitim ve test setleri oluşturuluyor")
    X_train,X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Model tanımlama ve yapay sinir ağı oluşturma
    print("Model oluşturuluyor")
    model = models.Sequential()
    model.add(layers.Dense(256, activation='relu', input_shape=(X_train.shape[1],)))
    model.add(layers.Dense(128, activation='relu'))
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.Dense(8, activation='softmax'))

    model.compile(optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy'])

    # Model eğitilmesi
    print("Model eğitiliyor")
    history = model.fit(X_train, y_train,
    epochs=30,
    batch_size=128,
    validation_data=(X_test, y_test))

    # Test sonuçları
    print("Test ediliyor")
    test_loss, test_acc = model.evaluate(X_test, y_test)
    print(f'Test accuracy: {test_acc}')

    # Modeli kaydetme
    print("Model kaydediliyor")
    model.save('models/' + model_version + '/' + 'model.h5')
    print("Model kaydedildi, model versiyonu: " + model_version)