import os
import sys
import numpy as np
from sklearn.preprocessing import LabelEncoder
from keras.models import load_model
from findgenre import extract_features

# Eğitilmiş modellerin dosya adlarına göre, en son sürüm numarasını alır.
def get_latest_model_version():
    latest_version = 1
    for folder in os.listdir('models'):
        if folder.startswith('model_v'):
            version_str = folder.split('_v')[1]
            version = int(version_str)
            latest_version = max(latest_version, version)
    return "model_v{}".format(latest_version)

# Tahmin fonksiyonu
def predict_genre(file_path, model_version):
    # Load the model
    model = load_model(f'models/{model_version}/model.h5')

    # Etiket kodlayıcıyı yükleyin
    label_encoder = LabelEncoder()
    label_encoder = np.load(f'models/{model_version}/label_encoder.npy', allow_pickle=True).item()
    print(f"Label encoder classes: {label_encoder.classes_}")

    # Girdi dosyasından özellikleri ayıklayın
    chroma, mfcc, spectral_contrast, tonnetz = extract_features(file_path)

    # Özellikleri standartlaştırın
    features = np.hstack([chroma, mfcc, spectral_contrast, tonnetz])
    features = (features - features.mean()) / features.std()

    # Modeli kullanarak türü tahmin edin
    genre_prediction = model.predict(np.array([features]))
    print(f"Genre prediction: {genre_prediction}")

    # Tür tahmininin kodunu çöz
    predicted_genre = label_encoder.inverse_transform(np.argmax(genre_prediction, axis=1))[0]

    return predicted_genre

# Ana fonksiyon
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python predict_genre.py [path_to_audio_file]")
    else:
        file_path = sys.argv[1]
        model_version = get_latest_model_version()
        print(f"Kullanılan model: {model_version}")
        genre = predict_genre('files/' + file_path, model_version)
        print(f"Dosyanın türü: {genre}")
